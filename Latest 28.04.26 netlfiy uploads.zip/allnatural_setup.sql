-- ═══════════════════════════════════════════════════════════════════════
--  AllNatural — Full database setup
--  Safe to run on a fresh OR existing database.
--  Run in Supabase → SQL Editor → New Query → Run
-- ═══════════════════════════════════════════════════════════════════════

-- ── STEP 1: DROP OLD POLICIES (must happen before anything else) ─────
drop policy if exists "anon_insert_users"      on an_users;
drop policy if exists "anon_upsert_users"      on an_users;
drop policy if exists "anon_insert_checkins"   on an_checkins;
drop policy if exists "anon_insert_mh"         on an_mh_checkins;
drop policy if exists "anon_insert_tests"      on an_tests;
drop policy if exists "anon_insert_products"   on an_products;
drop policy if exists "anon_insert_washdays"   on an_wash_days;
drop policy if exists "anon_insert_installs"   on an_style_installs;
drop policy if exists "anon_insert_takedowns"  on an_takedowns;

-- ── STEP 2: CREATE TABLES (if they don't exist yet) ──────────────────

create table if not exists an_users (
  id           text primary key,
  hair_type    text,
  hair_mode    text,
  goals        jsonb,
  challenge    text,
  wash_freq    text,
  gender       text,
  age          text,
  avatar_idx   int default 0,
  app_version  text,
  last_seen    timestamptz,
  display_name text,
  username     text,
  public_bio   text,
  xp           int default 0,
  streak       int default 0,
  share_hair_type  boolean default true,
  share_goals      boolean default true,
  share_streak     boolean default true,
  share_badges     boolean default true,
  share_routine    boolean default false,
  share_products   boolean default false,
  share_tests      boolean default false
);

create table if not exists an_checkins (
  id        bigint generated always as identity primary key,
  user_id   text,
  type      text,
  date      text,
  answers   jsonb,
  xp        int default 0,
  ts        timestamptz default now()
);

create table if not exists an_mh_checkins (
  id        bigint generated always as identity primary key,
  user_id   text,
  date      text,
  answers   jsonb,
  ts        timestamptz default now()
);

create table if not exists an_tests (
  id        bigint generated always as identity primary key,
  user_id   text,
  test_id   text,
  result    jsonb,
  date      text,
  ts        timestamptz default now()
);

create table if not exists an_products (
  id        bigint generated always as identity primary key,
  user_id   text,
  name      text,
  brand     text,
  category  text,
  rating    int,
  notes     text,
  price     text,
  store     text,
  stock_pct int default 100,
  date      text,
  ts        timestamptz default now()
);

create table if not exists an_wash_days (
  id        bigint generated always as identity primary key,
  user_id   text,
  date      text,
  duration  int,
  steps     jsonb,
  notes     text,
  ts        timestamptz default now()
);

create table if not exists an_style_installs (
  id        bigint generated always as identity primary key,
  user_id   text,
  style     text,
  date      text,
  tension   int,
  notes     text,
  ts        timestamptz default now()
);

create table if not exists an_takedowns (
  id        bigint generated always as identity primary key,
  user_id   text,
  style     text,
  date      text,
  days_kept int,
  condition text,
  ts        timestamptz default now()
);

create table if not exists an_tokens (
  id          bigint generated always as identity primary key,
  token       text unique not null,
  name        text,
  contact     text,
  hair_type   text,
  created_at  timestamptz default now(),
  expires_at  timestamptz,
  active      boolean default true,
  use_count   int default 0,
  last_used   timestamptz
);

create table if not exists an_access_requests (
  id              bigint generated always as identity primary key,
  token_attempted text,
  ua              text,
  ts              timestamptz default now(),
  status          text default 'blocked'
);

create table if not exists an_beta_requests (
  id           bigint generated always as identity primary key,
  name         text,
  contact      text,
  hair_type    text,
  agreed_terms boolean,
  status       text default 'pending',
  token_sent   text,
  ts           timestamptz default now()
);

-- ── STEP 3: ADD COLUMNS TO EXISTING TABLES (safe — if not exists) ────
alter table an_users add column if not exists display_name      text;
alter table an_users add column if not exists username          text;
alter table an_users add column if not exists public_bio        text;
alter table an_users add column if not exists xp                int default 0;
alter table an_users add column if not exists streak            int default 0;
alter table an_users add column if not exists share_hair_type   boolean default true;
alter table an_users add column if not exists share_goals       boolean default true;
alter table an_users add column if not exists share_streak      boolean default true;
alter table an_users add column if not exists share_badges      boolean default true;
alter table an_users add column if not exists share_routine     boolean default false;
alter table an_users add column if not exists share_products    boolean default false;
alter table an_users add column if not exists share_tests       boolean default false;

-- ── STEP 4: DISABLE RLS ON ALL TABLES ────────────────────────────────
alter table an_users           disable row level security;
alter table an_checkins        disable row level security;
alter table an_mh_checkins     disable row level security;
alter table an_tests           disable row level security;
alter table an_products        disable row level security;
alter table an_wash_days       disable row level security;
alter table an_style_installs  disable row level security;
alter table an_takedowns       disable row level security;
alter table an_tokens          disable row level security;
alter table an_access_requests disable row level security;
alter table an_beta_requests   disable row level security;

-- ── STEP 5: GRANT ACCESS ─────────────────────────────────────────────
grant all on an_users           to anon, authenticated;
grant all on an_checkins        to anon, authenticated;
grant all on an_mh_checkins     to anon, authenticated;
grant all on an_tests           to anon, authenticated;
grant all on an_products        to anon, authenticated;
grant all on an_wash_days       to anon, authenticated;
grant all on an_style_installs  to anon, authenticated;
grant all on an_takedowns       to anon, authenticated;
grant all on an_tokens          to anon, authenticated;
grant all on an_access_requests to anon, authenticated;
grant all on an_beta_requests   to anon, authenticated;

-- ── STEP 6: VERIFY ───────────────────────────────────────────────────
-- All an_ tables should show rowsecurity = false
select tablename, rowsecurity
from pg_tables
where schemaname = 'public'
  and tablename like 'an_%'
order by tablename;

-- ═══════════════════════════════════════════════════════════════════════
--  HOW TO ADD A BETA TESTER (run one per person):
--
--  insert into an_tokens (token, name, contact, hair_type, expires_at)
--  values ('Anita2024', 'Anita M.', '+27 82 000 0000', '4C',
--          now() + interval '4 weeks');
--
--  Send them: allnatural_final.html?t=Anita2024
-- ═══════════════════════════════════════════════════════════════════════
